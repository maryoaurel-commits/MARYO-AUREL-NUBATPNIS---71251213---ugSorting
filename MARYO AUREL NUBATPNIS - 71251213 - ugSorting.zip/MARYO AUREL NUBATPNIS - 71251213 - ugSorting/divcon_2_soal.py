# Data mahasiswa dan 5 nilai UG
mahasiswa = [
    {"nama": "Andi", "nilai": [80, 75, 90, 70, 85]},
    {"nama": "Budi", "nilai": [60, 65, 70, 55, 60]},
    {"nama": "Citra", "nilai": [90, 85, 95, 88, 92]},
    {"nama": "Deni", "nilai": [70, 75, 65, 72, 68]},
    {"nama": "Eka", "nilai": [85, 80, 78, 90, 87]},
    {"nama": "Fajar", "nilai": [65, 70, 68, 60, 72]},
    {"nama": "Gina", "nilai": [88, 92, 85, 90, 87]},
    {"nama": "Hadi", "nilai": [75, 80, 70, 78, 72]},
    {"nama": "Intan", "nilai": [55, 60, 65, 58, 62]},
    {"nama": "Joko", "nilai": [78, 82, 75, 80, 85]}
]


# Menghitung rata-rata nilai setiap mahasiswa
for mhs in mahasiswa:
    mhs["rata"] = sum(mhs["nilai"]) / len(mhs["nilai"])


# Divide and Conquer - Merge Sort
def merge_sort(data):
    if len(data) <= 1:
        return data
    
    tengah = len(data) // 2
    kiri = merge_sort (data[:tengah])
    kanan = merge_sort (data[tengah:])
    
    return merge(kiri, kanan)

def merge(kiri, kanan):
    hasil = []
    i = 0
    j = 0
    
    while i < len(kiri) and j < len(kanan):
        if kiri[i]["rata"] >= kanan[j]["rata"]:
            hasil.append(kiri[i])
            i += 1
        else:
            hasil.append(kanan[j])
            j += 1         
    while i < len(kiri):
            hasil.append(kiri[i])
            i += 1
    while j < len(kanan):
            hasil.append(kanan[j])
            j += 1
        
    return hasil


# Menghitung rata-rata keseluruhan
rata_keseluruhan = sum(m["rata"] for m in mahasiswa) / len(mahasiswa)

# Mengurutkan mahasiswa menggunakan Merge Sort
mahasiswa_urut = merge_sort(mahasiswa)

atas = []
bawah = []

for mhs in mahasiswa_urut:
    if mhs["rata"] >= rata_keseluruhan:
        atas.append(mhs)
    else:
        bawah.append(mhs)
        
# Menampilkan hasil rata-rata keseluruhan

print("\n=== DI ATAS / SAMA DENGAN RATA-RATA ===")
for i, mhs in enumerate(atas, 1):
    print(f"{i}. {mhs['nama']} - Nilai: {mhs['nilai']} - Rata - rata: {mhs['rata']:.1f}")

# Tampilkan List di atas / sama dengan rata-rata
print("\n=== DI BAWAH RATA-RATA ===")
for i, mhs in enumerate(bawah, 1):
    print(f"{i}. {mhs['nama']} - Nilai: {mhs['nilai']} - Rata - rata: {mhs['rata']:.1f}")
    
# Tampilkan List di bawah rata-rata